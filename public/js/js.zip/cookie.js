var username = $.cookie('username');
var token = $.cookie('token');
